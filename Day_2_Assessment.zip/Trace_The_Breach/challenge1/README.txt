Challenge 1 - The Leaked Secret Commit

Scenario:
A developer accidentally exposed a secret during development.
The issue was fixed before release.

Task:
Investigate the repository history and identify the exposed secret.

Flag Format:
FLAG{...}