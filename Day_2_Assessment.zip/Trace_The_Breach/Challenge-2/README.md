Challenge 2 - The Poisoned CI Pipeline

Scenario
An engineer modified the CI pipeline shortly before leaving the company.

Security suspects an unauthorized telemetry collection stage was added.

Task
Review the CI/CD pipeline configuration and build artifacts.

Identify the hidden token used by the suspicious stage.

Flag Format:
FLAG{...}