Challenge 3 – Supply Chain Incident Reconstruction

Scenario

A dependency update introduced a security incident.

Security investigators collected source code,
commit history records,
and CI pipeline logs.

Task

Reconstruct what happened and identify the
verification token associated with the incident.

Flag Format:
FLAG{...}