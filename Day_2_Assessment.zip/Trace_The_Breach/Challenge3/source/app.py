import internal_utils

print("Application Started")