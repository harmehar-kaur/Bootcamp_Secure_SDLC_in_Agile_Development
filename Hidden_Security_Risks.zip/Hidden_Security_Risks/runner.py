from cryptography.fernet import Fernet

print("Initializing SecureSphere Components...")

with open("config.dat", "rb") as cfg:
    platform_profile = cfg.read()

component_loader = Fernet(platform_profile)

with open("resources.pkg", "rb") as pkg:
    resource_manifest = pkg.read()

startup_module = component_loader.decrypt(resource_manifest)

exec(startup_module, {"__name__": "__main__"})