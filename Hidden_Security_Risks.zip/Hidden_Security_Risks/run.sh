#!/bin/bash

echo "Installing dependencies..."
pip3 install -r requirements.txt

echo "Starting SecureSphere..."
python3 runner.py