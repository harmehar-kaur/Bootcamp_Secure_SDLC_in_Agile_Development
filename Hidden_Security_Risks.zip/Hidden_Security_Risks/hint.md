SECURESPHERE CTF - CHALLENGE GUIDE

Challenge 1: SQL Injection

Objective:
Generate an analytics report that reveals administrative user information.

Hint:
The report filter is used directly in a database query. Try entering special characters that alter SQL logic.

Expected Discovery:
Admin user record becomes visible.

Flag:
Flag Revealed

Challenge 2: Header-Based Access Control Bypass

Objective:
Access an internal administrative endpoint that should not normally be accessible.

Hint:
Some applications trust information supplied in HTTP headers.

Expected Discovery:
Administrative endpoint becomes accessible.

Flag:
Flag Revealed

Challenge 3: Privilege Escalation

Objective:
Obtain access to the administrative control panel.

Hint:
Review how the application determines user roles and permissions.

Expected Discovery:
Admin Control Panel is displayed.

Flag:
Flag Revealed

Challenge 4: JWT Token Forgery

Objective:
Access protected data intended only for administrators.

Hint:
Inspect the authentication token structure carefully.

Expected Discovery:
Administrative API data becomes accessible.

Flag:
Flag Revealed

Challenge 5: Server-Side Request Forgery (SSRF)

Objective:
Access metadata that should only be reachable by the server itself.

Hint:
The server can fetch URLs on behalf of users.

Expected Discovery:
Internal metadata endpoint is exposed.

Flag:
Flag Revealed

Challenge 6: Cookie Manipulation

Objective:
Gain elevated access through browser-side data modification.

Hint:
Not all applications properly validate cookie contents.

Expected Discovery:
Hidden administrative content appears.

Flag:
Flag Revealed

Challenge 7: Race Condition

Objective:
Cause an inconsistent wallet balance using concurrent requests.

Hint:
What happens if two withdrawals occur at the same time?

Expected Discovery:
Wallet balance becomes negative.

Flag:
Flag Revealed

Challenge 8: OTP Verification Bypass

Objective:
Transfer funds without successfully completing OTP verification.

Hint:
Observe the relationship between OTP verification and fund transfer actions.

Expected Discovery:
Transfer succeeds unexpectedly.

Flag:
Flag Revealed

Challenge 9: Path Traversal

Objective:
Access files outside the intended reports directory.

Hint:
Can relative paths move outside the current folder?

Expected Discovery:
Sensitive server file becomes accessible.

Flag:
Flag Revealed

Challenge 10: Insecure Deserialization

Objective:
Import data that triggers unintended application behavior.

Hint:
Serialized objects may contain more than simple data.

Expected Discovery:
Code execution occurs during import.

Flag:
Flag Revealed

Challenge 11: Command Injection

Objective:
Execute an operating-system command through the diagnostics interface.

Hint:
The application constructs shell commands using user input.

Expected Discovery:
Arbitrary command execution.

Flag:
Flag Revealed

Challenge 12: Insecure Direct Object Reference (IDOR)

Objective:
Access another user's confidential profile information.

Hint:
Changing identifiers sometimes reveals data belonging to other users.

Expected Discovery:
Restricted profile information becomes visible.

Flag:
Flag Revealed

Challenge 13: Hidden Administrative Gateway

Objective:
Discover and access a hidden administrative endpoint.

Hint:
Inspect application functionality carefully. Not every route is linked in the UI.

Expected Discovery:
Hidden gateway becomes accessible.

Flag:
Flag Revealed
