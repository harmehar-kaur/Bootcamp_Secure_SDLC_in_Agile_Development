@echo off
echo Installing dependencies...
pip install -r requirements.txt

echo Starting SecureSphere...
python runner.py

pause